# Installing Javascript Google Code Style #

1. Open IntelliJ
2. File > Settings > Editor > Code Style > Javascript
3. Click the gear next to the Scheme dropdown > Import Scheme > 
Intellij IDEA code style XML
4. Select intellij-java-google-style.xml
5. Ensure that the Schemes dropdown for Javascript is set